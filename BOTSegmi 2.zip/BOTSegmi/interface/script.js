document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();  // Empêche l'envoi du formulaire par défaut

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Vérification basique pour la démo (à remplacer par une authentification réelle)
    if (username === "test" && password === "password") {
        alert("Connexion réussie !");
        // Redirige vers le serveur Discord ou un autre endroit (par exemple, une page protégée)
        window.location.href = "https://discord.com/invite/YOUR_INVITE_LINK";
    } else {
        alert("Nom d'utilisateur ou mot de passe incorrect !");
    }
});
// Tu peux ajouter ici des interactions si nécessaire
// Par exemple, pour tracker le clic sur le bouton et afficher une alerte si besoin

document.querySelector('.join-btn').addEventListener('click', function() {
    alert('Vous allez être redirigé vers notre serveur Discord.');
});
