// Fonction pour changer la langue
function changeLanguage() {
    const language = document.getElementById('language').value;

    // Object contenant les traductions
    const translations = {
        fr: {
            "welcome-title": "Bienvenue sur SEGMI Community",
            "welcome-text": "Découvrez toutes les informations utiles, échangez avec d'autres membres et obtenez de l'aide grâce à notre bot intégré.",
            "join-btn": "Rejoindre la Communauté",
            "doc-title": "Documentation du Bot SEGMI",
            "doc-text": "Notre bot Discord vous aide à obtenir des informations sur les programmes, les examens, et bien plus encore.",
            "info-command": "!info - Informations sur les inscriptions, programmes et événements.",
            "exam-command": "!exam - Horaires et programmes d'examen.",
            "help-command": "!help - Liste complète des commandes disponibles.",
        },
        en: {
            "welcome-title": "Welcome to SEGMI Community",
            "welcome-text": "Discover all useful information, interact with other members, and get help through our integrated bot.",
            "join-btn": "Join the Community",
            "doc-title": "SEGMI Bot Documentation",
            "doc-text": "Our Discord bot helps you get information about programs, exams, and more.",
            "info-command": "!info - Information about registrations, programs, and events.",
            "exam-command": "!exam - Exam schedules and programs.",
            "help-command": "!help - Full list of available commands.",
        },
        ar: {
            "welcome-title": "مرحبًا بك في SEGMI Community",
            "welcome-text": "اكتشف جميع المعلومات المفيدة، تفاعل مع الأعضاء الآخرين، واحصل على المساعدة من خلال الروبوت المتكامل.",
            "join-btn": "انضم إلى المجتمع",
            "doc-title": "وثائق بوت SEGMI",
            "doc-text": "يساعدك بوت Discord لدينا في الحصول على معلومات حول البرامج والامتحانات وأكثر.",
            "info-command": "!info - معلومات حول التسجيلات، البرامج، والفعاليات.",
            "exam-command": "!exam - جداول وبرامج الامتحانات.",
            "help-command": "!help - قائمة كاملة بالأوامر المتاحة.",
        }
    };

    // Mettre à jour les éléments de la page en fonction de la langue sélectionnée
    document.getElementById('welcome-title').innerText = translations[language]["welcome-title"];
    document.getElementById('welcome-text').innerText = translations[language]["welcome-text"];
    document.getElementById('join-btn').innerText = translations[language]["join-btn"];
    document.getElementById('doc-title').innerText = translations[language]["doc-title"];
    document.getElementById('doc-text').innerText = translations[language]["doc-text"];
    document.getElementById('info-command').innerText = translations[language]["info-command"];
    document.getElementById('exam-command').innerText = translations[language]["exam-command"];
    document.getElementById('help-command').innerText = translations[language]["help-command"];
}
