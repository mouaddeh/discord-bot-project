from flask import Flask, jsonify, request
import discord
from discord.ext import commands

# Crée une instance du bot Discord
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

# Créer une instance de Flask
app = Flask(__name__)

# Démarrer le bot
@bot.event
async def on_ready():
    print(f'Bot connecté en tant que {bot.user}')

# API pour obtenir des informations du bot
@app.route('/botinfo', methods=['GET'])
def bot_info():
    # Ici, tu peux récupérer des informations spécifiques du bot
    # Exemple: envoie un message ou récupère une donnée du bot
    return jsonify({"message": "Bot en ligne et prêt à fonctionner."})

# API pour envoyer une commande au bot
@app.route('/sendcommand', methods=['POST'])
def send_command():
    command = request.json.get('command')
    if command:
        # Envoie une commande au bot Discord (dans un canal spécifique)
        channel_id = 1234567890  # Remplace par l'ID du canal Discord
        channel = bot.get_channel(channel_id)
        bot.loop.create_task(channel.send(command))  # Envoie la commande sous forme de message
        return jsonify({"status": "success", "message": "Commande envoyée au bot"})
    return jsonify({"status": "error", "message": "Commande invalide"}), 400

# Démarre le serveur Flask
if __name__ == '__main__':
    bot.run('TON_TOKEN_ICI')  # Remplace par ton token Discord
    app.run(debug=True)
