document.addEventListener('DOMContentLoaded', () => {
    const sections = document.querySelectorAll('.content-section'); // Toutes les sections
    const docLink = document.getElementById('doc-link'); // Lien Documentation
    const joinLink = document.getElementById('join-link'); // Lien Rejoindre
    const homeLink = document.getElementById('home-btn'); // Lien Accueil

    // Fonction pour afficher une section et masquer les autres
    function showSection(sectionId) {
        sections.forEach((section) => {
            if (section.id === sectionId) {
                section.style.display = 'block'; // Affiche la section ciblée
            } else {
                section.style.display = 'none'; // Masque les autres sections
            }
        });
    }

    // Gestion du clic sur "Documentation"
    docLink.addEventListener('click', (e) => {
        e.preventDefault();
        showSection('doc-section'); // Affiche uniquement la documentation
    });

    // Gestion du clic sur "Rejoindre la Communauté"
    joinLink.addEventListener('click', (e) => {
        e.preventDefault();
        showSection('join-section'); // Affiche uniquement la section "Rejoindre"
    });

    // Gestion du clic sur "Accueil"
    homeLink.addEventListener('click', (e) => {
        e.preventDefault();
        showSection('hero-section'); // Affiche uniquement la section "Accueil"
    });

    // Affiche la section d'accueil par défaut
    showSection('hero-section');
});
